
package Clases;
public class Criterio {
    private int id_criterio;
    private String nombre;

    public int getId_criterio() {
        return id_criterio;
    }

    public void setId_criterio(int id_criterio) {
        this.id_criterio = id_criterio;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String criterio) {
        this.nombre = criterio;
    }

    public Criterio(int id_criterio, String criterio) {
        this.id_criterio = id_criterio;
        this.nombre = criterio;
    }
    public Criterio(String criterio) {
        this.id_criterio = id_criterio;
        this.nombre = criterio;
    }
    
}
