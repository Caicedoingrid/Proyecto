
package Clases;

public class Evidencia {
    
   private int id_evidencia;
   private String tipo_evidencia;
   private String estado_evidencia;
   private Criterio tipo_criterio;
   private String archivo;

    public int getId_evidencia() {
        return id_evidencia;
    }

    public void setId_evidencia(int id_evidencia) {
        this.id_evidencia = id_evidencia;
    }

    public String getTipo_evidencia() {
        return tipo_evidencia;
    }

    public void setTipo_evidencia(String tipo_evidencia) {
        this.tipo_evidencia = tipo_evidencia;
    }

    public String getEstado_evidencia() {
        return estado_evidencia;
    }

    public void setEstado_evidencia(String estado_evidencia) {
        this.estado_evidencia = estado_evidencia;
    }

    public Criterio getTipo_criterio() {
        return tipo_criterio;
    }

    public void setTipo_criterio(Criterio tipo_criterio) {
        this.tipo_criterio = tipo_criterio;
    }

    public String getArchivo() {
        return archivo;
    }

    public void setArchivo(String archivo) {
        this.archivo = archivo;
    }

    public Evidencia(int id_evidencia, String tipo_evidencia, String estado_evidencia, Criterio tipo_criterio, String archivo) {
        this.id_evidencia = id_evidencia;
        this.tipo_evidencia = tipo_evidencia;
        this.estado_evidencia = estado_evidencia;
        this.tipo_criterio = tipo_criterio;
        this.archivo = archivo;
    }

    public Evidencia(String tipo_evidencia, String estado_evidencia, Criterio tipo_criterio, String archivo) {
        this.tipo_evidencia = tipo_evidencia;
        this.estado_evidencia = estado_evidencia;
        this.tipo_criterio = tipo_criterio;
        this.archivo = archivo;
    }

    public Evidencia() {
    }
    
    
   
   
}
