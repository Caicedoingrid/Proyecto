
package Clases;

public class Usuario {
    
    private int id_usuario;
    private String cedula;
    private String nombre_docente;
    private String apellido;
    private String correo;
    private Criterio tipo_criterio;

    public int getId_usuario() {
        return id_usuario;
    }

    public void setId_usuario(int id_usuario) {
        this.id_usuario = id_usuario;
    }

    public String getCedula() {
        return cedula;
    }

    public void setCedula(String cedula) {
        this.cedula = cedula;
    }

    public String getNombre_docente() {
        return nombre_docente;
    }

    public void setNombre_docente(String nombre_docente) {
        this.nombre_docente = nombre_docente;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public String getCorreo() {
        return correo;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }

    public Criterio getTipo_criterio() {
        return tipo_criterio;
    }

    public void setTipo_criterio(Criterio tipo_criterio) {
        this.tipo_criterio = tipo_criterio;
    }

    public Usuario(int id_usuario, String cedula, String nombre_docente, String apellido, String correo, Criterio tipo_criterio) {
        this.id_usuario = id_usuario;
        this.cedula = cedula;
        this.nombre_docente = nombre_docente;
        this.apellido = apellido;
        this.correo = correo;
        this.tipo_criterio = tipo_criterio;
    }

    public Usuario(String cedula, String nombre_docente, String apellido, String correo, Criterio tipo_criterio) {
        this.cedula = cedula;
        this.nombre_docente = nombre_docente;
        this.apellido = apellido;
        this.correo = correo;
        this.tipo_criterio = tipo_criterio;
    }
    
    
        public Usuario() {

    }
    
 
    
    
}
