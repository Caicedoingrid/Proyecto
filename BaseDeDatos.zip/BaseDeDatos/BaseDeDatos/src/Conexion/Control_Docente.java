

package Conexion;

import Clases.Criterio;
import Clases.Usuario;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import javax.swing.JOptionPane;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

public class Control_Docente {
    
    Conexion conexion = new Conexion();
    Connection cn = conexion.getConexion();
    PreparedStatement ps;

    public boolean Registrar(Object obj,int criterio) {
        Usuario objC = (Usuario) obj;
        boolean estado = false;

        // Llamada al procedimiento almacenado
        try {
            CallableStatement cst = cn.prepareCall("{call Docente (null,?,?,?,?,?,'Insert')}");
            // Parametro 1 del procedimiento almacenado
            cst.setString(1, objC.getCedula());
            cst.setString(2, objC.getNombre_docente());
            cst.setString(3, objC.getApellido());
            cst.setString(4, objC.getCorreo());
            cst.setInt(5, criterio);

            // Ejecuta el procedimiento almacenado
            boolean registro = cst.execute();

            if (registro == false) {
                JOptionPane.showMessageDialog(null, "Registro completado");
                estado = true;
            } else {
                JOptionPane.showMessageDialog(null, "Registro no completado");
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);

        }

    
        return estado;
    }
         public boolean Modificar(Object obj,int criterio) {
        Usuario objC = (Usuario) obj;
        boolean estado = false;

        // Llamada al procedimiento almacenado
        try {
            CallableStatement cst = cn.prepareCall("{call Docente (?,?,?,?,?,?,'Update')}");
            // Parametro 1 del procedimiento almacenado
            cst.setInt(1, objC.getId_usuario());
            cst.setString(2, objC.getCedula());
            cst.setString(3, objC.getNombre_docente());
            cst.setString(4, objC.getApellido());
            cst.setString(5, objC.getCorreo());
            cst.setInt(6, criterio);

            // Ejecuta el procedimiento almacenado
            boolean registro = cst.execute();

            if (registro == false) {
                JOptionPane.showMessageDialog(null, "Registro actualizado");
                estado = true;
            } else {
                JOptionPane.showMessageDialog(null, "Registro no actualizado");
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);

        }

    
        return estado;
    }
    
     public boolean Eliminar(int id_usuario) {
        
        boolean estado = false;

        // Llamada al procedimiento almacenado
        try {
            CallableStatement cst = cn.prepareCall("{call Docente (?,null,null,null,null,null,'Delete')}");
            // Parametro 1 del procedimiento almacenado
            cst.setInt(1, id_usuario);
            // Ejecuta el procedimiento almacenado
            boolean registro = cst.execute();

            if (registro == false) {
                JOptionPane.showMessageDialog(null, "Registro eliminado");
                estado = true;
            } else {
                JOptionPane.showMessageDialog(null, "Registro no eliminado");
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);

        }

    
        return estado;
    }
    
    public ArrayList<Usuario> ConsultarUsuarios(String str) {
        
         ArrayList<Usuario> docentes = new ArrayList<>();
       
         //String sql="SELECT * FROM cliente WHERE apellido LIKE '%"+valor+"%'";   
         String sql="SELECT * FROM MostrarDocente WHERE MostrarDocente.cedula LIKE '%"+str+"%'";  
          Conexion conexion=new Conexion();
        Connection cn=conexion.getConexion();
        
         try {
             //para crear la ejecución de la sentencia sql con el OBJETO STATEMENT st
            Statement st=cn.createStatement();
            //para recoger el resultado del SELECT con el objeto RESULSET, luego de ejecutar el query SQL SELECT
            ResultSet rs=st.executeQuery(sql);
            
            //para insertar los registros en la tabla obtenidos del SELECT
            while(rs.next()){
                
                Usuario d =new Usuario();
                
                d.setId_usuario(rs.getInt ("id_docente"));
                d.setCedula(rs.getString("cedula"));
                d.setNombre_docente(rs.getString("nombre_docente"));
                d.setApellido(rs.getString("apellido"));
                d.setCorreo(rs.getString("correo"));
                d.setTipo_criterio(new Criterio(rs.getInt("id_criterio"),rs.getString("nombre")));
                
                docentes.add(d);
            }
           cn.close();  //cerrar la conexion

            System.out.println("tabla cargado");
        } catch (Exception e) {
            System.out.println(e);
        }
        return docentes;
    }


}