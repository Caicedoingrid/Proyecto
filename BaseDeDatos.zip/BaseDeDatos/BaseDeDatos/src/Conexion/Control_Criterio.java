

package Conexion;

import Clases.Criterio;
import java.sql.CallableStatement;
import java.sql.PreparedStatement;
import javax.swing.JOptionPane;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

public class Control_Criterio {

    Conexion conexion = new Conexion();
    Connection cn = conexion.getConexion();
    PreparedStatement ps;

    public boolean Registrar(Object obj) {
        Criterio objC = (Criterio) obj;
        boolean estado = false;

        // Llamada al procedimiento almacenado
        try {
            CallableStatement cst = cn.prepareCall("{call Criterio (null,?,'Insert')}");
            // Parametro 1 del procedimiento almacenado
            cst.setString(1, objC.getNombre());

            // Ejecuta el procedimiento almacenado
            boolean registro = cst.execute();

            if (registro == false) {
                JOptionPane.showMessageDialog(null, "Registro completado");
                estado = true;
            } else {
                JOptionPane.showMessageDialog(null, "Registro no completado");
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);

        }
        

   
        return estado;
    }
 public ArrayList<Criterio> VerCriterio() {

        ArrayList<Criterio> criterios = new ArrayList<>();
        Conexion conexion = new Conexion();
        Connection cn = conexion.getConexion();
        String sql = "Select * from MostrarCriterio";

        try {
            Statement st = cn.createStatement();
            ResultSet rs = st.executeQuery(sql);
            while (rs.next()) {
                Criterio c;
                c = new Criterio(rs.getString("nombre"));
                criterios.add(c);
            }
           cn.close();  //cerrar la conexion

            System.out.println("tabla cargado");
        } catch (Exception e) {
            System.out.println(e);
        }
        return criterios;
    }
}


