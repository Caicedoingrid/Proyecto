package Conexion;

import Clases.Criterio;
import Clases.Evidencia;
import Clases.Usuario;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import javax.swing.JOptionPane;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

public class Control_Evidencia {
    
    Conexion conexion = new Conexion();
    Connection cn = conexion.getConexion();
    PreparedStatement ps;

    public boolean Registrar(Object obj,int criterio) {
        Evidencia objC = (Evidencia) obj;
        boolean estado = false;

        // Llamada al procedimiento almacenado
        try {
            CallableStatement cst = cn.prepareCall("{call Evidencia (null,?,?,?,'Insert')}");
            // Parametro 1 del procedimiento almacenado
            cst.setString(1, objC.getTipo_evidencia());
            cst.setString(2, objC.getEstado_evidencia());
            cst.setInt(3, criterio);

            // Ejecuta el procedimiento almacenado
            boolean registro = cst.execute();

            if (registro == false) {
                JOptionPane.showMessageDialog(null, "Registro completado");
                estado = true;
            } else {
                JOptionPane.showMessageDialog(null, "Registro no completado");
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);

        }

    
        return estado;
    }
         public boolean Modificar(Object obj,int criterio) {
        Evidencia objC = (Evidencia) obj;
        boolean estado = false;

        // Llamada al procedimiento almacenado
        try {
            CallableStatement cst = cn.prepareCall("{call Evidencia (?,?,?,?,'Update')}");
            // Parametro 1 del procedimiento almacenado
            cst.setInt(1, objC.getId_evidencia());
            cst.setString(2, objC.getTipo_evidencia());
            cst.setString(3, objC.getEstado_evidencia());
            cst.setInt(4, criterio);

            // Ejecuta el procedimiento almacenado
            boolean registro = cst.execute();

            if (registro == false) {
                JOptionPane.showMessageDialog(null, "Registro actualizado");
                estado = true;
            } else {
                JOptionPane.showMessageDialog(null, "Registro no actualizado");
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);

        }

    
        return estado;
    }
    
     public boolean Eliminar(int id_evidencia) {
       
        boolean estado = false;

        // Llamada al procedimiento almacenado
        try {
            CallableStatement cst = cn.prepareCall("{call Evidencia (?,null,null,null'Delete')}");
            // Parametro 1 del procedimiento almacenado
            cst.setInt(1, id_evidencia);
            // Ejecuta el procedimiento almacenado
            boolean registro = cst.execute();

            if (registro == false) {
                JOptionPane.showMessageDialog(null, "Registro eliminado");
                estado = true;
            } else {
                JOptionPane.showMessageDialog(null, "Registro no eliminado");
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);

        }

    
        return estado;
    }
    
    public ArrayList<Evidencia> ConsultarEvidencia(String str) {
        
         ArrayList<Evidencia> evidencia = new ArrayList<>();
       
         //String sql="SELECT * FROM cliente WHERE apellido LIKE '%"+valor+"%'";   
         String sql="SELECT * FROM MostrarEvidencia WHERE MostrarEvidencia.id_evidencia LIKE '%"+str+"%'";  
          Conexion conexion=new Conexion();
        Connection cn=conexion.getConexion();
        
         try {
             //para crear la ejecución de la sentencia sql con el OBJETO STATEMENT st
            Statement st=cn.createStatement();
            //para recoger el resultado del SELECT con el objeto RESULSET, luego de ejecutar el query SQL SELECT
            ResultSet rs=st.executeQuery(sql);
            
            //para insertar los registros en la tabla obtenidos del SELECT
            while(rs.next()){
                
                Evidencia e =new Evidencia();
                
                e.setId_evidencia(rs.getInt ("id_evidencia"));
                e.setTipo_evidencia(rs.getString("tipo_evidencia"));
                e.setEstado_evidencia(rs.getString("estado_evidencia"));
                e.setTipo_criterio(new Criterio(rs.getInt("id_criterio"),rs.getString("nombre")));
                
                evidencia.add(e);
            }
           cn.close();  //cerrar la conexion

            System.out.println("tabla cargado");
        } catch (Exception e) {
            System.out.println(e);
        }
        return evidencia;
    }


}